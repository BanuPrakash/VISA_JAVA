package com.visa.prj.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.visa.prj.entity.Product;

public class ProductDaoJdbcImpl implements ProductDao {

	static {
		try {
			Class.forName(DBConfig.getString("DB_DRIVER")); //$NON-NLS-1$
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public List<Product> getProducts() {
		List<Product> products = new ArrayList<Product>();
		Connection con = null;
		try {
			con = DriverManager.getConnection(DBConfig.getString("DB_URL"), DBConfig.getString("DB_USER"), DBConfig.getString("DB_PWD")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			Statement stmt = con.createStatement();
			String sql = "select id, name, price from product"; //$NON-NLS-1$
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Product p = new Product(rs.getInt("id"),  //$NON-NLS-1$
						rs.getString("name"), rs.getDouble("price")); //$NON-NLS-1$ //$NON-NLS-2$
				products.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return products;
	}

	public void addProduct(Product product) {
		Connection con = null;
		try {
			con = DriverManager.getConnection(DBConfig.getString("DB_URL"), DBConfig.getString("DB_USER"), DBConfig.getString("DB_PWD")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			String sql = "insert into product(id, name, price) values (?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, product.getId());
			ps.setString(2, product.getName());
			ps.setDouble(3, product.getPrice());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
