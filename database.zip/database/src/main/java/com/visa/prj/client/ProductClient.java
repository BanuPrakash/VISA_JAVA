package com.visa.prj.client;

import java.util.List;

import com.visa.prj.dao.ProductDao;
import com.visa.prj.dao.ProductDaoJdbcImpl;
import com.visa.prj.entity.Product;

public class ProductClient {

	public static void main(String[] args) {
		addProduct();
		listProduct();
	}

	private static void addProduct() {
		ProductDao productDao = new ProductDaoJdbcImpl();
		Product p = new Product(50,"Test", 22.00);
		productDao.addProduct(p);
	}

	private static void listProduct() {
		ProductDao productDao = new ProductDaoJdbcImpl();
		
		List<Product> products = productDao.getProducts();
		
		for(Product p : products) {
			System.out.println(p.getId() + ", " + p.getName() + ", " + p.getPrice() );
		}
		
	}

}
